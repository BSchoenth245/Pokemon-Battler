#include <iostream>
using namespace std;
/*

Contains the array of all loaded pokemon and their stats

*/

string pokemonArray[2][9] = {
    //name, type 1, type 2(if applicable), hp, attack, defense, sp att, sp def, speed
    {"Venesaur", "grass", "poison", "80", "82", "83", "100", "100", "80"},
    {"Charizard", "fire", "flying", "78", "84", "78", "109", "85", "100"}
};
