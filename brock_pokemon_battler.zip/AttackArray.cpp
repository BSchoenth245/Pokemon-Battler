#include <iostream>
using namespace std;
/*

    Contains the array of all possible attacks that pokemon can have and players can choose from

*/

string pokemonAttackArray[2][5] = {
    //name, type, move type(0=physical,1=special,2=status), power, accuracy
    {"Vine Whip", "grass", "0", "45", "100"},
    {"Fire Fang", "fire", "0", "65", "95"}
};